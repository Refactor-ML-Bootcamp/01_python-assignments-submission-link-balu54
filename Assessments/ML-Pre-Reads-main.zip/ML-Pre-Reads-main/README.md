# ML-Pre-Reads
- https://www.kaggle.com/learn
- https://towardsdatascience.com/machine-learning-basics-part-1-a36d38c7916
- https://machinelearningmastery.com/basic-concepts-in-machine-learning/
